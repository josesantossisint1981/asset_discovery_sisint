import { defineConfig } from 'vite';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = dirname(fileURLToPath(import.meta.url));

export default defineConfig({
  build: {
    outDir: resolve(root, '../../static/topology-embed'),
    emptyOutDir: true,
    cssCodeSplit: false,
    lib: {
      entry: resolve(root, 'src/embed.jsx'),
      name: 'SisintTopology',
      formats: ['es'],
      fileName: () => 'topology.js',
      cssFileName: 'topology'
    }
  }
});
