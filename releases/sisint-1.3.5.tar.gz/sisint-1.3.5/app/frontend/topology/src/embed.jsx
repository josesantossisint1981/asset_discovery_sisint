import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.jsx';
import './embed.css';

const roots = new WeakMap();

export function mount(element) {
  if (!element || roots.has(element)) return;

  const shadow = element.attachShadow({ mode: 'open' });

  const css = document.createElement('link');
  css.rel = 'stylesheet';
  css.href = '/static/topology-embed/topology.css';
  shadow.appendChild(css);

  const container = document.createElement('div');
  container.className = 'sisint-topology-inner';
  shadow.appendChild(container);

  const root = createRoot(container);
  root.render(<App />);

  const observer = new MutationObserver(() => {
    if (!element.isConnected) {
      observer.disconnect();
      root.unmount();
      roots.delete(element);
    }
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });

  roots.set(element, { root, observer });
}
