import { useEffect, useState } from 'react';
import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  Handle,
  Position,
  useNodesState,
} from '@xyflow/react';

import '@xyflow/react/dist/style.css';
import './App.css';

function EquipmentNode({ data }) {
  return (
    <div className="equipment">
      <Handle type="target" position={Position.Left} />

      <div className="equipment-type">{data.kind}</div>
      <div className="equipment-name">{data.name}</div>
      <div className="equipment-ip">{data.ip || data.mac || 'IP desconhecido'}</div>

      <Handle type="source" position={Position.Right} />
    </div>
  );
}

const nodeTypes = {
  equipment: EquipmentNode,
};


function makeGraph(assets) {
  const nodes = [];
  const edges = [];
  const groups = new Map();
  const unlinked = [];

  const assetId = (a, i) =>
    `asset:${String(a.mac || a.ip || i)}`;

  const assetNode = (a, i, position) => ({
    id: assetId(a, i),
    type: 'equipment',
    position,
    data: {
      kind: 'ATIVO',
      name: a.hostname || a.model || a.ip || a.mac || 'Sem nome',
      ip: a.ip,
      mac: a.mac,
      vendor: a.vendor,
      model: a.model,
      firmware: a.firmware,
      vlan: a.vlan,
      switch: a.switch,
      switch_port: a.switch_port,
    },
  });

  assets.forEach((a, i) => {
    if (a.switch && a.switch_port) {
      const name = String(a.switch);

      if (!groups.has(name)) {
        groups.set(name, []);
      }

      groups.get(name).push({ a, i });
    } else {
      unlinked.push({ a, i });
    }
  });

  let top = 60;
  const usedSwitches = new Set();

  for (const [name, items] of groups) {
    const actual = unlinked.find(({ a, i }) => {
      if (usedSwitches.has(i)) return false;

      const exact = [a.hostname, a.name, a.ip, a.model].some(
        value => String(value || '').toLowerCase() === name.toLowerCase()
      );

      const isSwitch = /switch|dgs[- ]?1250/i.test(
        [a.hostname, a.name, a.model, a.kind, a.type].join(' ')
      );

      return exact || (groups.size === 1 && isSwitch);
    });

    if (actual) usedSwitches.add(actual.i);

    const real = actual?.a;
    const switchId = real
      ? assetId(real, actual.i)
      : `switch:${name}`;

    nodes.push({
      id: switchId,
      type: 'equipment',
      position: {
        x: 50,
        y: top + ((items.length - 1) * 115) / 2,
      },
      data: {
        kind: 'SWITCH',
        name: real?.model || real?.hostname || real?.name || name,
        ip: real?.ip || '',
        mac: real?.mac || '',
        vendor: real?.vendor || '',
        model: real?.model || '',
        firmware: real?.firmware || '',
      },
    });

    items.forEach(({ a, i }, j) => {
      const node = assetNode(a, i, {
        x: 390,
        y: top + j * 115,
      });

      nodes.push(node);

      edges.push({
        id: `link:${switchId}:${node.id}`,
        source: switchId,
        target: node.id,
        type: 'smoothstep',
        animated: true,
        label: `${a.switch_port} · SIM.`,
        style: {
          stroke: '#38bdf8',
          strokeWidth: 2,
        },
        labelStyle: {
          fill: '#38bdf8',
          fontSize: 11,
        },
      });
    });

    top += items.length * 115 + 100;
  }

  unlinked
    .filter(({ i }) => !usedSwitches.has(i))
    .forEach(({ a, i }, j) => {
    nodes.push(
      assetNode(a, i, {
        x: 750 + (j % 2) * 210,
        y: 60 + Math.floor(j / 2) * 115,
      })
    );
  });

  return { nodes, edges };
}

export default function App() {
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges] = useState([]);
  const [selected, setSelected] = useState(null);
  const [status, setStatus] = useState('A consultar descoberta...');
  const [runId, setRunId] = useState(null);
  const [flow, setFlow] = useState(null);

  useEffect(() => {
    let alive = true;

    async function poll() {
      try {
        const response = await fetch('/api/discovery', {
          credentials: 'same-origin',
        });

        if (!response.ok) {
          throw new Error(`API de descoberta: HTTP ${response.status}`);
        }

        const { runs = [] } = await response.json();

        const sorted = [...runs].sort(
          (a, b) => Number(b.id) - Number(a.id)
        );

        const active = sorted.find(r =>
          ['running', 'queued'].includes(r.status)
        );

        const requestedId = new URLSearchParams(
          window.location.search
        ).get('run');

        const run = requestedId
          ? sorted.find(r => String(r.id) === requestedId)
          : sorted[0];

        if (!run) {
          if (alive) {
            setNodes([]);
            setRunId(null);
            setStatus('Nenhum levantamento disponível');
          }
          return;
        }

        const result = await fetch(`/api/discovery/${run.id}`, {
          credentials: 'same-origin',
        });

        if (!result.ok) {
          throw new Error(`Levantamento: HTTP ${result.status}`);
        }

        const data = await result.json();

        if (!alive) return;

        const assets = Array.isArray(data.assets) ? data.assets : [];

        setRunId(run.id);
        setStatus(data.run?.status || run.status || 'desconhecido');

        const next = makeGraph(assets);

        setNodes(previous => {
          const positions = new Map(
            previous.map(node => [node.id, node.position])
          );

          return next.nodes.map(node => ({
            ...node,
            position: positions.get(node.id) || node.position,
          }));
        });
        setEdges(next.edges);

      } catch (error) {
        if (alive) setStatus(`Erro: ${error.message}`);
      }
    }

    poll();

    const timer = setInterval(poll, 1500);

    return () => {
      alive = false;
      clearInterval(timer);
    };
  }, [setNodes]);

  useEffect(() => {
    if (!flow || !nodes.length) return;

    const timer = setTimeout(() => {
      flow.fitView({ padding: 0.2, duration: 300 });
    }, 150);

    return () => clearTimeout(timer);
  }, [flow, nodes.length]);

  return (
    <div className="sisint-app">
      <header className="sisint-header">
        <div>
          <h1>SISINT 1.3.4</h1>
          <p>Topologia / Descoberta automática</p>
        </div>

        <span className="demo-badge">
          {runId ? `Levantamento #${runId}` : 'SEM LEVANTAMENTO'}
        </span>
      </header>

      <section className="sisint-content">
        <div className="map-area">
          <ReactFlow
            nodes={nodes}
            edges={edges}
            nodeTypes={nodeTypes}
            onNodesChange={onNodesChange}
            onNodeClick={(_, node) => setSelected(node.data)}
            onPaneClick={() => setSelected(null)}
            onInit={setFlow}
            nodesConnectable={false}
            fitView
            colorMode="dark"
          >
            <Background color="#26354d" gap={24} />
            <Controls />
            <MiniMap nodeColor="#38bdf8" />
          </ReactFlow>
        </div>

        <aside className="details">
          <h2>Descoberta SISINT</h2>

          <p><strong>Estado:</strong> {status}</p>
          <p><strong>Equipamentos:</strong> {nodes.length}</p>

          <hr />

          <h2>Equipamento selecionado</h2>

          {selected ? (
            <div>
              <p><strong>Nome:</strong> {selected.name}</p>
              <p><strong>IP:</strong> {selected.ip || '—'}</p>
              <p><strong>MAC:</strong> {selected.mac || '—'}</p>
              <p><strong>Fabricante:</strong> {selected.vendor || '—'}</p>
              <p><strong>Modelo:</strong> {selected.model || '—'}</p>
              <p><strong>Firmware:</strong> {selected.firmware || '—'}</p>
              <p><strong>VLAN:</strong> {selected.vlan ?? '—'}</p>
            </div>
          ) : (
            <p>Seleciona um equipamento para ver os detalhes.</p>
          )}

          <hr />

          <p className="note">
            Equipamentos obtidos da API de descoberta da SISINT.
            Ligações obtidas por SNMP FDB. Não confirmam ligação física direta.
          </p>
        </aside>
      </section>
    </div>
  );
}
